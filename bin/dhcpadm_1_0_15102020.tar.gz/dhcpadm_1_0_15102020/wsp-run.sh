#!/bin/bash

PERL5LIB='/opt/dhcpadm/libs' /opt/dhcpadm/wsp.pl -h '/opt/dhcpadm' -a $1

